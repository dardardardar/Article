
<?php $__env->startSection('content'); ?>
<div class="container bg-white my-5 p-5">
    <h1 id="title"></h1>
    <div class="row">
        <div class="col-10"><p id="author">By: </p></div>
        <div class="col" id="action"></div>
    </div>
    <hr>
    <p id="content"></p>
    
</div>







<script>

var id =  window.location.href.slice(window.location.href.indexOf('=') + 1)
$( document ).ready(function() {
    
    var uri = 'http://127.0.0.1:8000/api/article/' + id;
    $.ajax({
    url: uri,
    type: 'GET',
    data: {
        format: 'json'
    }, 
    error: function() {
    
    },
    success: function(data) {
        $('#title').append(data.title);
        $('#author').append(data.author);
        $('#content').append(data.content);
        $('#action').append('<a href="/form?id='+data.id+'" class="btn btn-primary">Edit</a> | <button class="btn btn-primary" onclick="deletebtn('+data.id+')" >Delete</button>')
        }  
    });
});

function deletebtn(id){
    var conf = confirm("dsd")

    if(conf){
        var uri = 'http://127.0.0.1:8000/api/article/'+id;
        //e.preventDefault();
        $.ajax({
            url: uri,
            type: 'DELETE',
            dataType: 'json',
            error: function() {
                console.log('An error occurred.');
                alert('Error')
            },
            success: function(data) {
                console.log('Submission was successful.');
                alert('Sucdessful')
                window.location.replace("/");

            }
              
        });
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/details.blade.php ENDPATH**/ ?>