@extends('layout.layout')
@section('content')
    
<div class="container bg-white my-5 p-5">
    <div class="row">
        <div class="col"><h1 >Hello there..</h1></div>
        <div class="col"><a href="/form" class="btn btn-primary float-right">Add Item</a></div>
    </div>
    
   
    <div class="list-group" id="dat">
        
      </div>
</div>

<script>

    // A $( document ).ready() block.
$( document ).ready(function() {
    var uri = 'http://127.0.0.1:8000/api/article';
    $.ajax({
    url: uri,
    type: 'GET',
    data: {
        format: 'json'
    }, 
    error: function() {
    
    },
    success: function(data) {
        for(var i = 0 ; i < data.length ; i++) {
            var elem = '';
            var content = data[i].content;
            elem += '<a href="/article?id='+data[i].id+'" class="list-group-item list-group-item-action flex-column align-items-start my-1"><div class="d-flex w-100 justify-content-between"><h5 class="mb-1">'+data[i].title +'</h5> <small>'+data[i].created+'</small> </div><p class="mb-1 w-75">'+content.substring(0, 200)+'...</p></a>';
            $('#dat').append(elem);
        }
        }  
    });
});
</script>
@endsection