@extends('layout.layout')
@section('content')
    

<div class="container bg-white my-5 p-5">
    <h1>Add new article</h1>
    <hr>
    <div class="form-row">
        <div class="col">
            <label for="exampleInputEmail1">Article Title</label>
            <input type="text" class="form-control" id="newtitle" placeholder="Title">
            
        </div>
        <div class="col">
          <label for="exampleInputPassword1">Author</label>
          <input type="text" class="form-control" id="newauthor" placeholder="Author">
        </div>
      </div>
      <br>
      <div class="form-group">
        <label for="exampleFormControlTextarea1">Content</label>
        <textarea class="form-control" id="newcontent" rows="10"></textarea>
      </div>
      <button id="btnsubmit" class="btn btn-primary">Submit</button>
</div>


<script>
var id =  window.location.href.slice(window.location.href.indexOf('=') + 1)
    // A $( document ).ready() block.
$( document ).ready(function() {
    
    if(id != ""){
        $('h1').empty()
       
        var uri = 'http://127.0.0.1:8000/api/article/' + id;
        $.ajax({
    url: uri,
    type: 'GET',
    data: {
        format: 'json'
    }, 
    error: function() {
    
    },
    success: function(data) {
        $('#newtitle').attr("placeholder",data.title);
        $('#newauthor').attr("placeholder",data.author);
        $('#newcontent').attr("placeholder",data.content);
        $('h1').append('Edit '+ data.title.substring(0,20))
        }  
    });
    
    }
});
$('#btnsubmit').click(function(e){

    var newtitle = $('#newtitle').val();
    var newauthor = $('#newauthor').val();
    var newcontent = $('#newcontent').val();

    if(newtitle == ""){

    }
    else if(newauthor == ""){
        
    }
    else if(newcontent == ""){
        
    }
    else{
        if(id == ""){
            var d = new Date();
        var uri = 'http://127.0.0.1:8000/api/article?title='+newtitle+'&content='+newcontent+'&author='+newauthor+'&created='+d.getDate()  + "-" + (d.getMonth()+1) + "-" + d.getFullYear();
        e.preventDefault();
        $.ajax({
            url: uri,
            type: 'POST',
            dataType: 'json',
            error: function() {
                console.log('An error occurred.');
                alert('Error')
            },
            success: function(data) {
                console.log('Submission was successful.');
                alert('Sucdessful')
                window.location.replace("/");

            }
              
        });
        }
        else{
            var d = new Date();
        var uri = 'http://127.0.0.1:8000/api/article?title='+newtitle+'&content='+newcontent+'&author='+newauthor+'&created='+d.getDate()  + "-" + (d.getMonth()+1) + "-" + d.getFullYear();
        e.preventDefault();
        var head = '{"_method" : "PUT"}';
        $.ajax({
            
            url: uri,
            type: 'PUT',
            
            data:head,
            error: function() {
                console.log('An error occurred.');
                alert('Error')
            },
            success: function(data) {
                console.log('Submission was successful.');
                alert('Sucdessful')
                window.location.replace("/");

            }
              
        });
        }
    }
});
</script>
@endsection