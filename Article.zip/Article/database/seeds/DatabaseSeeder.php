<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{

     
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
          
        DB::table('articles')->insert([[
            'title'=>'What Is BPD?',
            'content'=>'What is borderline personality disorder? If you’ve been friends with me on facebook for a while chances are you’ve seen me post about it more than once. See depression and anxiety are well known and fairly common. If I say I have depression you will most likely know what I am talking about and you can grasp how I feel. But when I say I have borderline personality disorder I get weird looks and confused faces. “What is that?” “Does that mean you have different personalities?” “That sounds scary…” Those are some of the reactions I have gotten over the past few months since being diagnosed, which is one of the many reasons why I post about it on facebook and why I am talking about it today. There are a lot of unknowns surrounding BPD and a lot of stigma attached to the diagnosis. I am going to go over the symptoms of BPD and how each manifests in me in my daily life.',
            'author'=>'Everlee Gibbs',
            'created'=>date('Y/m/d')
        ],
        [
            'title'=>'What Is Splitting in Borderline Personality Disorder (BPD)?',
            'content'=>'To split something means to divide it. Those with BPD tend to characterize themselves, other people, and situations in black and white. In other words, they may suddenly characterize people, objects, beliefs, or situations as either all good or all bad.
            They may do this even though they know the world is complex, and good and bad can exist together in one.
            Those with BPD often seek outside validation without considering their own emotions about themselves, others, objects, beliefs, and situations. This can make them more prone to splitting, as they attempt to shield themselves from anxiety caused by potential abandonment, loss of trust, and betrayal.',
            'author'=>'Lennie Randal',
            'created'=>date('Y/m/d')
        ],
        [
            'title'=>'What It’s Like to Lose Your ‘Favorite Person’ When You Have Borderline Personality Disorder',
            'content'=>'Like many other people with borderline personality disorder (BPD), I had a “favorite person” or “FP.” This is used in the BPD community to refer to the person your emotions become dependent upon. My FP was also my best friend “V” (not her real name).
            “V” and I had a very intense and relatively short friendship. We met online, started talking and she became my FP very quickly. I could tell her anything and she was always there for me. If I texted her, she usually replied immediately. She never made me feel like I was being a burden. She was kind and caring. At the time I met her, I had already gone through some things in life, including losing people previously. I told her about it and she was understanding and showed a lot of care.
            After several months of talking, things started to get more intense and my BPD attachment was growing stronger — without me consciously realizing this. Things started to get worse with my health (I actually don’t think this was a coincidence. This included panic attacks, extreme anxiety and general lack of self-care).',
            'author'=>'Eliza Kennard',
            'created'=>date('Y/m/d')
        ],
        [
            'title'=>'When Jealousy Brings Out My Borderline Cling',
            'content'=>'One of the more complicated parts of having borderline personality disorder (BPD) is when you develop that intense, unbreakable connection to one specific person: your “favorite person,” or FP for short. An FP can be a beautiful, magical part of someone with BPD’s life: it is often the sole person who shows us unconditional love, accepts us completely, makes us feel safe and often even finds the beauty in the person BPD makes us. The negative side, though, is this: we find ourselves needing our FP just as much as we need oxygen to breathe.
            The fear of abandonment becomes incredibly intense in regards to my FP. I’m so insecure in our relationship — even with daily reminders that my FP loves me and isn’t leaving, that I’ll never become replaced or be “second best.” I often describe the actions that result from the fear of abandonment of my FP as my “borderline cling.” All of the actions are frantic attempts to avoid the abandonment I fear is around the corner, with or without any reasonable proof.
            ',
            'author'=>'Judie Frost',
            'created'=>date('Y/m/d')
        ],
        [
            'title'=>'What Is BPD?',
            'content'=>'What is borderline personality disorder? If you’ve been friends with me on facebook for a while chances are you’ve seen me post about it more than once. See depression and anxiety are well known and fairly common. If I say I have depression you will most likely know what I am talking about and you can grasp how I feel. But when I say I have borderline personality disorder I get weird looks and confused faces. “What is that?” “Does that mean you have different personalities?” “That sounds scary…” Those are some of the reactions I have gotten over the past few months since being diagnosed, which is one of the many reasons why I post about it on facebook and why I am talking about it today. There are a lot of unknowns surrounding BPD and a lot of stigma attached to the diagnosis. I am going to go over the symptoms of BPD and how each manifests in me in my daily life.',
            'author'=>'Everlee Gibbs',
            'created'=>date('Y/m/d')
        ],
        [
            'title'=>'What Is Splitting in Borderline Personality Disorder (BPD)?',
            'content'=>'To split something means to divide it. Those with BPD tend to characterize themselves, other people, and situations in black and white. In other words, they may suddenly characterize people, objects, beliefs, or situations as either all good or all bad.
            They may do this even though they know the world is complex, and good and bad can exist together in one.
            Those with BPD often seek outside validation without considering their own emotions about themselves, others, objects, beliefs, and situations. This can make them more prone to splitting, as they attempt to shield themselves from anxiety caused by potential abandonment, loss of trust, and betrayal.',
            'author'=>'Lennie Randal',
            'created'=>date('Y/m/d')
        ],
        [
            'title'=>'What It’s Like to Lose Your ‘Favorite Person’ When You Have Borderline Personality Disorder',
            'content'=>'Like many other people with borderline personality disorder (BPD), I had a “favorite person” or “FP.” This is used in the BPD community to refer to the person your emotions become dependent upon. My FP was also my best friend “V” (not her real name).
            “V” and I had a very intense and relatively short friendship. We met online, started talking and she became my FP very quickly. I could tell her anything and she was always there for me. If I texted her, she usually replied immediately. She never made me feel like I was being a burden. She was kind and caring. At the time I met her, I had already gone through some things in life, including losing people previously. I told her about it and she was understanding and showed a lot of care.
            After several months of talking, things started to get more intense and my BPD attachment was growing stronger — without me consciously realizing this. Things started to get worse with my health (I actually don’t think this was a coincidence. This included panic attacks, extreme anxiety and general lack of self-care).',
            'author'=>'Eliza Kennard',
            'created'=>date('Y/m/d')
        ],
        [
            'title'=>'When Jealousy Brings Out My Borderline Cling',
            'content'=>'One of the more complicated parts of having borderline personality disorder (BPD) is when you develop that intense, unbreakable connection to one specific person: your “favorite person,” or FP for short. An FP can be a beautiful, magical part of someone with BPD’s life: it is often the sole person who shows us unconditional love, accepts us completely, makes us feel safe and often even finds the beauty in the person BPD makes us. The negative side, though, is this: we find ourselves needing our FP just as much as we need oxygen to breathe.
            The fear of abandonment becomes incredibly intense in regards to my FP. I’m so insecure in our relationship — even with daily reminders that my FP loves me and isn’t leaving, that I’ll never become replaced or be “second best.” I often describe the actions that result from the fear of abandonment of my FP as my “borderline cling.” All of the actions are frantic attempts to avoid the abandonment I fear is around the corner, with or without any reasonable proof.
            ',
            'author'=>'Judie Frost',
            'created'=>date('Y/m/d')
        ],
        [
            'title'=>'What Is BPD?',
            'content'=>'What is borderline personality disorder? If you’ve been friends with me on facebook for a while chances are you’ve seen me post about it more than once. See depression and anxiety are well known and fairly common. If I say I have depression you will most likely know what I am talking about and you can grasp how I feel. But when I say I have borderline personality disorder I get weird looks and confused faces. “What is that?” “Does that mean you have different personalities?” “That sounds scary…” Those are some of the reactions I have gotten over the past few months since being diagnosed, which is one of the many reasons why I post about it on facebook and why I am talking about it today. There are a lot of unknowns surrounding BPD and a lot of stigma attached to the diagnosis. I am going to go over the symptoms of BPD and how each manifests in me in my daily life.',
            'author'=>'Everlee Gibbs',
            'created'=>date('Y/m/d')
        ],
        [
            'title'=>'What Is Splitting in Borderline Personality Disorder (BPD)?',
            'content'=>'To split something means to divide it. Those with BPD tend to characterize themselves, other people, and situations in black and white. In other words, they may suddenly characterize people, objects, beliefs, or situations as either all good or all bad.
            They may do this even though they know the world is complex, and good and bad can exist together in one.
            Those with BPD often seek outside validation without considering their own emotions about themselves, others, objects, beliefs, and situations. This can make them more prone to splitting, as they attempt to shield themselves from anxiety caused by potential abandonment, loss of trust, and betrayal.',
            'author'=>'Lennie Randal',
            'created'=>date('Y/m/d')
        ],
        [
            'title'=>'What It’s Like to Lose Your ‘Favorite Person’ When You Have Borderline Personality Disorder',
            'content'=>'Like many other people with borderline personality disorder (BPD), I had a “favorite person” or “FP.” This is used in the BPD community to refer to the person your emotions become dependent upon. My FP was also my best friend “V” (not her real name).
            “V” and I had a very intense and relatively short friendship. We met online, started talking and she became my FP very quickly. I could tell her anything and she was always there for me. If I texted her, she usually replied immediately. She never made me feel like I was being a burden. She was kind and caring. At the time I met her, I had already gone through some things in life, including losing people previously. I told her about it and she was understanding and showed a lot of care.
            After several months of talking, things started to get more intense and my BPD attachment was growing stronger — without me consciously realizing this. Things started to get worse with my health (I actually don’t think this was a coincidence. This included panic attacks, extreme anxiety and general lack of self-care).',
            'author'=>'Eliza Kennard',
            'created'=>date('Y/m/d')
        ],
        [
            'title'=>'When Jealousy Brings Out My Borderline Cling',
            'content'=>'One of the more complicated parts of having borderline personality disorder (BPD) is when you develop that intense, unbreakable connection to one specific person: your “favorite person,” or FP for short. An FP can be a beautiful, magical part of someone with BPD’s life: it is often the sole person who shows us unconditional love, accepts us completely, makes us feel safe and often even finds the beauty in the person BPD makes us. The negative side, though, is this: we find ourselves needing our FP just as much as we need oxygen to breathe.
            The fear of abandonment becomes incredibly intense in regards to my FP. I’m so insecure in our relationship — even with daily reminders that my FP loves me and isn’t leaving, that I’ll never become replaced or be “second best.” I often describe the actions that result from the fear of abandonment of my FP as my “borderline cling.” All of the actions are frantic attempts to avoid the abandonment I fear is around the corner, with or without any reasonable proof.
            ',
            'author'=>'Judie Frost',
            'created'=>date('Y/m/d')
        ],
        ]);
       
    }
}
