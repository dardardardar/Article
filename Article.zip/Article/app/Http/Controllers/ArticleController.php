<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Article;

class ArticleController extends Controller
{
    function GetData(){
        $data = Article::get();
        return response()->json($data, 200);
    }
    function GetDataById($id){
        $data = Article::find($id);     
        return response()->json($data, 200);
    }
    function PostNewData(Request $request){
        $data = Article::create($request->all());
        return response()->json($data, 200);
    }
    function PutExistingData(Request $request,Article $article){
        $article->update($request->all());
        return response()->json($data, 200);
    }
    function DeleteData(Request $request,Article $article){
        $article->delete();
        return response()->json(null, 200);
    }
}
